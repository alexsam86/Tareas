# PrimerProyecto
Para poder ejecutar este proyecto en tu computador, deberás cumplir con los siguientes requisitos:

1. Tener node en su versión LTS instalado
2. Tener en CLI de Angular instalado
3. Descargar este proyecto como ZIP
4. Ejecutar el comando **npm install** dentro de la carpeta del proyecto, para generar la carpeta node_modules
5. ejecutar npm run start o ng serve para iniciar el proyecto
6. jugar
  